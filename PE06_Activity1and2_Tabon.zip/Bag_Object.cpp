#include <iostream>
#include <string>
#include "Bag.h"

using namespace std;

int main() {
    Bag bag1("Green", 10, "50kg");
    bag1.display();
    
    return 0;
}
