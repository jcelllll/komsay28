#include <iostream>
#include <string>
using namespace std;

class Person{
	private:
		private:
		string firstName;
		string lastName;
		char gender;
	public:
		string emailAdd;
		string cpNumber;
	Name(){}
	
	Name(string newfname, string newlname, char newgender, string newEmailadd, string newcpNumber){
		firstName = newfname;
		lastName= newlname;
		gender = newgender;
		emailAdd = newEmailadd;
		cpNumber = newcpNumber;
	}
		
	void setfname(string fname){
			firstName = fname;	
	}
	string getfname(){
			return firstName;
	}	
	void setlname(string lname){
			lastName = lname; 
	}
	string getlname(){
		return lastName;
	}	
	void setgender(char c){
		if( (c == 'M') || (c == 'F') ){
			gender = c;
	
		} 
		else{
			cout << "Invalid gender!!!" << endl;
		}
	}
	char getgender(){
		return gender;
	}
	void setEmailadd(string newEmailadd){
		emailAdd = newEmailadd;
	}
	string getEmailadd(){
		return emailAdd;
	}
	void setCpnumber(string newCpnumber){
		cpNumber = newCpnumber;
	}
	string getCpnumber(){
		return cpNumber;
	}
};
